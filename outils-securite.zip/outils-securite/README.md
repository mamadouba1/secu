# Outils de sécurité

Scripts pour contrôler la sécurité de mes sites avec Docker, et pour obtenir une explication en français des rapports.

> Ne scanner que des sites qui m'appartiennent ou pour lesquels j'ai une autorisation écrite.

## Contenu

| Fichier | Rôle |
|---|---|
| `scan.sh` | Mac / Linux : scan OWASP ZAP + Nuclei via Docker, puis explication |
| `scan.ps1` | Windows : même chose en PowerShell |
| `explique_rapport.py` | Lit un rapport ZAP (`.html` ou `.json`) ou Nuclei (`.txt`) et l'explique en français |
| `.github/workflows/scan-securite.yml` | Scan automatique chaque lundi sur GitHub |

## Utilisation

1. Lancer Docker Desktop (attendre « Engine running »).
2. Mac / Linux :
   ```bash
   chmod +x scan.sh
   ./scan.sh https://mon-site.com
   ```
   Windows :
   ```powershell
   .\scan.ps1 -Url https://mon-site.com
   ```
3. Les rapports sont dans `rapports/` (ignoré par Git).

Pour expliquer un rapport existant :
```bash
python3 explique_rapport.py rapports/rapport-zap_XXXX.json
```
Le format JSON est plus fiable que le HTML.

## Scan automatique (GitHub Actions)

1. Dépôt > Settings > Secrets and variables > Actions > onglet Variables > New repository variable
   - Nom : `SITE_URL`, valeur : `https://mon-site.com`
2. Onglet Actions > « Scan de sécurité » > Run workflow, ou attendre le lundi.
3. Le résumé en français apparaît dans la page de l'exécution, et les rapports sont téléchargeables dans « Artifacts ».

## Limites

Un scanner produit des faux positifs et ne vérifie ni la logique métier ni les droits d'accès (par ex. la RLS Supabase). Ces points se contrôlent à la main.
