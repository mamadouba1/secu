#!/usr/bin/env bash
# Scan de sécurité (ZAP + Nuclei via Docker) puis explication en français.
# Utilisation :  ./scan.sh https://ton-site.com
# Prérequis   :  Docker Desktop lancé, python3 installé.
set -uo pipefail

URL="${1:-}"
if [ -z "$URL" ]; then
  echo "Utilisation : ./scan.sh https://ton-site.com"
  exit 1
fi

read -r -p "Ce site t'appartient (ou tu as une autorisation écrite) ? (o/N) " REP
[[ "$REP" =~ ^[oOyY]$ ]] || { echo "Annulé."; exit 1; }

if ! docker info >/dev/null 2>&1; then
  echo "Docker ne répond pas : ouvre Docker Desktop et attends « Engine running »."
  exit 1
fi

DIR="$(cd "$(dirname "$0")" && pwd)"
OUT="$DIR/rapports"
DATE="$(date +%Y-%m-%d_%H-%M)"
mkdir -p "$OUT"
chmod a+w "$OUT"

echo "==> Scan ZAP (2 à 5 minutes)..."
docker run --rm -v "$OUT":/zap/wrk/:rw -t ghcr.io/zaproxy/zaproxy:stable \
  zap-baseline.py -t "$URL" \
  -r "rapport-zap_$DATE.html" -J "rapport-zap_$DATE.json" || true

echo "==> Scan Nuclei..."
docker run --rm -v "$OUT":/app projectdiscovery/nuclei:latest \
  -u "$URL" -severity low,medium,high,critical -o "/app/nuclei_$DATE.txt" || true

echo "==> Explication des résultats..."
cd "$OUT"
if [ -f "rapport-zap_$DATE.json" ]; then
  python3 "$DIR/explique_rapport.py" "rapport-zap_$DATE.json"
  mv -f rapport_explique.md "rapport_explique_zap_$DATE.md" 2>/dev/null || true
fi
if [ -s "nuclei_$DATE.txt" ]; then
  python3 "$DIR/explique_rapport.py" "nuclei_$DATE.txt"
  mv -f rapport_explique.md "rapport_explique_nuclei_$DATE.md" 2>/dev/null || true
fi

echo
echo "Terminé. Rapports dans : $OUT"
