#!/usr/bin/env python3
"""
Explique en français un rapport de scan de sécurité.

Formats pris en charge :
  - rapport ZAP HTML  (.html)
  - rapport ZAP JSON  (.json)  -> le plus fiable : ajouter  -J rapport.json  au scan ZAP
  - sortie Nuclei     (.txt)

Utilisation :
  python explique_rapport.py rapport-zap.html
  python explique_rapport.py                      (prend le rapport le plus récent du dossier)

Aucune installation nécessaire (Python 3.8+ suffit).
Le résultat s'affiche à l'écran et est enregistré dans rapport_explique.md
"""
import json
import re
import sys
from collections import defaultdict
from html.parser import HTMLParser
from pathlib import Path

# --------------------------------------------------------------------------
# Base de connaissances : (mot-clé dans le nom de l'alerte) -> (explication, correction)
# L'ordre compte : le premier mot-clé trouvé gagne.
# --------------------------------------------------------------------------
CONSEILS = [
    ("content security policy", "Le site n'envoie pas d'en-tête CSP. Cette protection limite les scripts autorisés à s'exécuter et réduit fortement l'impact d'une faille XSS.",
     "Ajouter l'en-tête Content-Security-Policy (Next.js : next.config.js > headers()). Commencer par Content-Security-Policy-Report-Only pour ne rien casser."),
    ("csp", "Politique CSP trop permissive ou mal configurée (ex. 'unsafe-inline', jokers *).",
     "Resserrer la CSP : lister uniquement les domaines réellement utilisés, utiliser des nonces plutôt que 'unsafe-inline'."),
    ("strict-transport-security", "HSTS absent : un navigateur peut encore tenter une connexion en HTTP non chiffré (risque d'interception).",
     "Ajouter Strict-Transport-Security: max-age=63072000; includeSubDomains; preload (Vercel/Next.js : via headers())."),
    ("anti-clickjacking", "Ton site peut être affiché dans une iframe d'un autre site : risque de clickjacking (clic piégé).",
     "Ajouter X-Frame-Options: DENY ou, mieux, la directive CSP frame-ancestors 'none'."),
    ("x-frame-options", "Protection contre l'affichage du site dans une iframe absente ou mal réglée (clickjacking).",
     "Ajouter X-Frame-Options: DENY ou CSP frame-ancestors 'none'."),
    ("x-content-type-options", "Le navigateur peut « deviner » le type d'un fichier (MIME sniffing) et exécuter un contenu inattendu.",
     "Ajouter X-Content-Type-Options: nosniff."),
    ("permissions policy", "Aucune restriction sur les fonctions du navigateur (caméra, micro, géolocalisation...) pour ton site et ses scripts tiers.",
     "Ajouter Permissions-Policy: camera=(), microphone=(), geolocation=() en n'autorisant que le nécessaire."),
    ("httponly", "Un cookie est lisible par JavaScript : s'il y a une faille XSS, il peut être volé (session détournée).",
     "Poser l'attribut HttpOnly sur les cookies de session / d'authentification."),
    ("secure flag", "Un cookie peut transiter en HTTP non chiffré.",
     "Poser l'attribut Secure sur tous les cookies."),
    ("samesite", "Un cookie est envoyé aussi lors de requêtes venant d'autres sites (risque CSRF).",
     "Poser SameSite=Lax (ou Strict) sur les cookies."),
    ("cookie", "Un cookie est mal configuré (attributs de sécurité manquants).",
     "Vérifier HttpOnly, Secure et SameSite sur chaque cookie."),
    ("csrf", "Des formulaires n'ont pas de jeton anti-CSRF : un site malveillant pourrait déclencher des actions au nom d'un utilisateur connecté.",
     "Utiliser des jetons anti-CSRF ou SameSite=Lax/Strict. Souvent un faux positif si l'API exige un jeton d'authentification dans un en-tête."),
    ("server leaks", "Le serveur révèle sa technologie ou sa version : utile pour un attaquant qui cherche des failles connues.",
     "Masquer l'en-tête Server / X-Powered-By (Next.js : poweredByHeader: false dans next.config.js)."),
    ("x-powered-by", "L'en-tête X-Powered-By révèle la technologie utilisée.",
     "Next.js : poweredByHeader: false dans next.config.js."),
    ("sub resource integrity", "Des scripts/styles chargés depuis un CDN externe n'ont pas de contrôle d'intégrité : si le CDN est compromis, le code malveillant s'exécute chez toi.",
     "Ajouter l'attribut integrity=\"sha384-...\" et crossorigin=\"anonymous\" sur les balises <script>/<link> externes, ou héberger ces fichiers toi-même."),
    ("cross-domain javascript", "Ton site charge des scripts depuis d'autres domaines : tu dépends de leur sécurité.",
     "Limiter les scripts tiers, ajouter SRI (integrity) et les autoriser explicitement dans la CSP."),
    ("cross-origin", "Les règles de partage entre origines (CORS / COOP / CORP) sont trop ouvertes ou absentes.",
     "Éviter Access-Control-Allow-Origin: * sur des données sensibles ; lister les origines autorisées."),
    ("cors", "Configuration CORS trop permissive.",
     "Remplacer * par la liste précise des origines autorisées."),
    ("spectre", "Absence d'isolation de site : protection contre les attaques de type Spectre.",
     "Ajouter Cross-Origin-Opener-Policy: same-origin et Cross-Origin-Resource-Policy: same-site (si compatible avec tes intégrations)."),
    ("timestamp disclosure", "Une valeur ressemblant à une date/horodatage apparaît dans la réponse. Presque toujours sans danger.",
     "Généralement un faux positif (identifiants, dates de contenu). À ignorer sauf si c'est une date interne sensible."),
    ("information disclosure", "Le site expose des informations internes (versions, chemins, commentaires, erreurs...).",
     "Désactiver les messages d'erreur détaillés en production et retirer les infos inutiles des réponses."),
    ("suspicious comment", "Des commentaires dans le code (HTML/JS) contiennent des mots comme TODO, password, admin...",
     "Vérifier qu'aucun secret ou info interne n'est dans le code livré. Le plus souvent un faux positif (bibliothèques)."),
    ("cache-control", "Des pages peuvent être mises en cache par le navigateur ou un proxy, y compris des pages privées.",
     "Pour les pages sensibles : Cache-Control: no-store, private."),
    ("storable", "Des réponses peuvent être stockées en cache par des intermédiaires.",
     "Sur les contenus privés, ajouter Cache-Control: no-store. Sur du contenu public, c'est normal."),
    ("modern web application", "Information : ZAP détecte une application moderne (SPA / Next.js) que son scan classique explore mal.",
     "Pas une faille. Pour un scan plus complet, utiliser le « AJAX spider » de ZAP."),
    ("content-type header missing", "Une réponse n'indique pas son type de contenu.",
     "Toujours définir Content-Type (et X-Content-Type-Options: nosniff)."),
    ("sql injection", "FAILLE GRAVE possible : des données saisies pourraient modifier une requête SQL.",
     "Utiliser des requêtes paramétrées / l'ORM (jamais de concaténation de chaînes). Avec Supabase, activer la RLS."),
    ("cross site scripting", "FAILLE GRAVE possible (XSS) : un attaquant peut injecter du script exécuté chez les visiteurs.",
     "Échapper toute donnée affichée, éviter dangerouslySetInnerHTML, ajouter une CSP stricte."),
    ("xss", "Possible injection de script (XSS).",
     "Échapper les données affichées et ajouter une CSP stricte."),
    ("vulnerable js library", "Une bibliothèque JavaScript utilisée a une vulnérabilité connue.",
     "Mettre à jour la bibliothèque (npm audit fix / Dependabot)."),
    ("private ip", "Une adresse IP interne apparaît dans les réponses.",
     "Retirer ces adresses des réponses publiques."),
    ("hash disclosure", "Une valeur ressemblant à un hash est exposée.",
     "Vérifier qu'il ne s'agit pas d'un mot de passe haché ; sinon le retirer."),
    ("base64", "Des données encodées en Base64 sont présentes dans la page.",
     "Vérifier qu'elles ne contiennent rien de sensible (Base64 n'est pas du chiffrement)."),
    ("redirect", "Une redirection peut être manipulée (open redirect) ou est inhabituelle.",
     "Valider les URL de redirection contre une liste blanche."),
]

RISQUES = {
    "high": ("🔴", "ÉLEVÉ", 0),
    "critical": ("🔴", "CRITIQUE", 0),
    "medium": ("🟠", "MOYEN", 1),
    "low": ("🟡", "FAIBLE", 2),
    "informational": ("🔵", "INFO", 3),
    "info": ("🔵", "INFO", 3),
}


def niveau(risk_text):
    cle = risk_text.strip().split()[0].lower() if risk_text.strip() else "info"
    return RISQUES.get(cle, ("⚪", risk_text or "?", 4))


def conseil_pour(nom):
    n = nom.lower()
    for mot, explication, correction in CONSEILS:
        if mot in n:
            return explication, correction
    return None, None


def nettoyer(texte):
    texte = re.sub(r"<[^>]+>", " ", texte or "")
    return re.sub(r"\s+", " ", texte).strip()


# --------------------------------------------------------------------------
# Lecture HTML (bibliothèque standard uniquement)
# --------------------------------------------------------------------------
class LecteurTableaux(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.lignes = []
        self._ligne = None
        self._cellule = None

    def handle_starttag(self, tag, attrs):
        if tag == "tr":
            self._ligne = []
        elif tag in ("td", "th") and self._ligne is not None:
            classes = dict(attrs).get("class", "") or ""
            self._cellule = {"tag": tag, "cls": classes, "txt": []}
        elif tag == "br" and self._cellule is not None:
            self._cellule["txt"].append(" ")

    def handle_data(self, data):
        if self._cellule is not None:
            self._cellule["txt"].append(data)

    def handle_endtag(self, tag):
        if tag in ("td", "th") and self._cellule is not None and self._ligne is not None:
            c = self._cellule
            self._ligne.append((c["tag"], c["cls"], nettoyer("".join(c["txt"]))))
            self._cellule = None
        elif tag == "tr" and self._ligne is not None:
            if self._ligne:
                self.lignes.append(self._ligne)
            self._ligne = None


def lire_html(chemin):
    lecteur = LecteurTableaux()
    lecteur.feed(Path(chemin).read_text(encoding="utf-8", errors="replace"))
    alertes, courante = [], None
    for cellules in lecteur.lignes:
        tag, cls, txt = cellules[0]
        if tag == "th" and "risk-" in cls and len(cellules) >= 2:
            courante = {"risque": txt, "nom": cellules[1][2], "champs": defaultdict(list)}
            alertes.append(courante)
        elif courante is not None and len(cellules) >= 2:
            courante["champs"][txt].append(cellules[1][2])
    return alertes


def lire_json(chemin):
    data = json.loads(Path(chemin).read_text(encoding="utf-8", errors="replace"))
    alertes = []
    for site in data.get("site", []):
        for a in site.get("alerts", []):
            champs = defaultdict(list)
            champs["Description"].append(nettoyer(a.get("desc", "")))
            champs["Solution"].append(nettoyer(a.get("solution", "")))
            champs["CWE Id"].append(str(a.get("cweid", "")))
            instances = a.get("instances", [])
            champs["Instances"].append(str(a.get("count", len(instances))))
            for i in instances:
                champs["URL"].append(i.get("uri", ""))
                if i.get("param"):
                    champs["Parameter"].append(i["param"])
                if i.get("evidence"):
                    champs["Evidence"].append(nettoyer(i["evidence"]))
            alertes.append({"risque": a.get("riskdesc", ""), "nom": a.get("name", ""), "champs": champs})
    return alertes


def lire_nuclei(chemin):
    """Lignes du type : [template-id] [http] [medium] https://site/chemin"""
    alertes = []
    for ligne in Path(chemin).read_text(encoding="utf-8", errors="replace").splitlines():
        m = re.search(r"\[([\w.\-:/]+)\]\s+\[(\w+)\]\s+\[(info|low|medium|high|critical)\]\s+(\S+)(.*)", ligne, re.I)
        if m:
            tpl, _proto, sev, url, reste = m.groups()
            champs = defaultdict(list)
            champs["URL"].append(url)
            if reste.strip():
                champs["Description"].append(reste.strip())
            alertes.append({"risque": sev, "nom": tpl, "champs": champs})
    return alertes


# --------------------------------------------------------------------------
# Rendu
# --------------------------------------------------------------------------
def construire_rapport(alertes, source):
    alertes = sorted(alertes, key=lambda a: niveau(a["risque"])[2])
    compte = defaultdict(int)
    for a in alertes:
        compte[niveau(a["risque"])[1]] += 1

    out = [f"# Rapport de sécurité expliqué — {source}", ""]
    out.append(f"**{len(alertes)} type(s) d'alerte détecté(s)** : " +
               ", ".join(f"{k} : {v}" for k, v in compte.items()) if alertes else "Aucune alerte détectée.")
    out.append("")

    for a in alertes:
        icone, label, _ = niveau(a["risque"])
        f = a["champs"]
        explication, correction = conseil_pour(a["nom"])
        urls = list(dict.fromkeys(f.get("URL", [])))
        out.append(f"## {icone} {a['nom']}  ({label})")
        out.append("")
        if explication:
            out.append(f"**En clair :** {explication}")
        else:
            desc = (f.get("Description") or [""])[0]
            out.append(f"**Description (ZAP) :** {desc[:400] or 'non fournie'}")
        if f.get("Instances"):
            out.append(f"**Occurrences :** {f['Instances'][0]}")
        if urls:
            out.append("**Pages concernées :** " + ", ".join(urls[:5]) + (" ..." if len(urls) > 5 else ""))
        if f.get("Parameter"):
            out.append("**Paramètre(s) :** " + ", ".join(dict.fromkeys(f["Parameter"])))
        if f.get("Evidence"):
            out.append("**Preuve relevée :** " + f["Evidence"][0][:200])
        sol = correction or (f.get("Solution") or [""])[0]
        if sol:
            out.append(f"**Comment corriger :** {sol}")
        if f.get("CWE Id") and f["CWE Id"][0] not in ("", "0", "-1"):
            out.append(f"**Référence :** CWE-{f['CWE Id'][0]} (cwe.mitre.org)")
        out.append("")

    urgents = [a for a in alertes if niveau(a["risque"])[2] <= 1]
    out.append("## Par où commencer")
    out.append("")
    if urgents:
        for a in urgents:
            out.append(f"1. {niveau(a['risque'])[0]} {a['nom']}")
        out.append("")
        out.append("Traite d'abord les alertes ÉLEVÉES et MOYENNES, puis les en-têtes manquants (rapides à corriger).")
    else:
        out.append("Aucune alerte élevée ou moyenne : corrige les alertes faibles quand tu peux (en-têtes de sécurité surtout).")
    out.append("")
    out.append("_Rappel : un scanner produit des faux positifs, et il ne vérifie ni la logique métier ni les droits d'accès "
               "(par ex. la RLS Supabase). Relis aussi ces points à la main._")
    return "\n".join(out)


def trouver_rapport():
    candidats = [p for p in Path(".").iterdir()
                 if p.suffix.lower() in (".html", ".json", ".txt") and ("rapport" in p.name.lower() or "nuclei" in p.name.lower())]
    return max(candidats, key=lambda p: p.stat().st_mtime) if candidats else None


def main():
    chemin = Path(sys.argv[1]) if len(sys.argv) > 1 else trouver_rapport()
    if not chemin or not chemin.exists():
        sys.exit("Fichier introuvable. Utilisation : python explique_rapport.py rapport-zap.html")

    ext = chemin.suffix.lower()
    if ext == ".json":
        alertes = lire_json(chemin)
    elif ext == ".txt":
        alertes = lire_nuclei(chemin)
    else:
        alertes = lire_html(chemin)

    if not alertes:
        print("Aucune alerte lue. Si le rapport contient pourtant des alertes, relance ZAP avec  -J rapport.json  "
              "(format plus fiable) et passe ce fichier au script.")
        return

    rapport = construire_rapport(alertes, chemin.name)
    print(rapport)
    Path("rapport_explique.md").write_text(rapport, encoding="utf-8")
    print("\n>>> Enregistré dans rapport_explique.md")


if __name__ == "__main__":
    main()
