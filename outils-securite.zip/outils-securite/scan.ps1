# Scan de sécurité (ZAP + Nuclei via Docker) puis explication en français (Windows).
# Utilisation :  .\scan.ps1 -Url https://ton-site.com
param([Parameter(Mandatory=$true)][string]$Url)

$rep = Read-Host "Ce site t'appartient (ou tu as une autorisation écrite) ? (o/N)"
if ($rep -notmatch '^[oOyY]$') { Write-Host "Annulé."; exit 1 }

$date = Get-Date -Format "yyyy-MM-dd_HH-mm"
$out = Join-Path $PSScriptRoot "rapports"
New-Item -ItemType Directory -Force -Path $out | Out-Null

Write-Host "Scan ZAP de $Url ..." -ForegroundColor Cyan
docker run --rm -v "${out}:/zap/wrk/:rw" -t ghcr.io/zaproxy/zaproxy:stable `
  zap-baseline.py -t $Url -r "rapport-zap_$date.html" -J "rapport-zap_$date.json"

Write-Host "Scan Nuclei de $Url ..." -ForegroundColor Cyan
docker run --rm -v "${out}:/app" projectdiscovery/nuclei:latest `
  -u $Url -severity low,medium,high,critical -o "/app/nuclei_$date.txt"

Write-Host "Explication des résultats ..." -ForegroundColor Cyan
Push-Location $out
python "$PSScriptRoot\explique_rapport.py" "rapport-zap_$date.json"
if (Test-Path rapport_explique.md) { Move-Item -Force rapport_explique.md "rapport_explique_zap_$date.md" }
Pop-Location

Write-Host "Terminé. Rapports dans : $out" -ForegroundColor Green
